<footer class="footer">
    <div class="footer-content">
        <h3>Mobile Store</h3>
        <p>Explore Best Quality Mobiles In Affordable Price</p>
    </div>
    <div class="footer-bottom">
        <small>All rights reserved by &copy;Mobile Store</small>
    </div>
</footer>

</body>

</html>