<?php

$conn = mysqli_connect('localhost','root','','mobile_store') or die(mysqli_error($conn));

?>